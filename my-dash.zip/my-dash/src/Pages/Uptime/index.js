import { Avatar, Rate, Space, Table, Typography } from "antd";
import { useEffect, useState } from "react";
import { getUptime, getInventory } from "../../API";

function Uptime() {
  const [loading, setLoading] = useState(false);
  const [dataSource, setDataSource] = useState([]);

  useEffect(() => {
    setLoading(true);
    getUptime().then((res) => {
    //   setDataSource(res.users);
    setDataSource(res);
      setLoading(false);
    });
  }, []);

  return (
    <Space size={20} direction="vertical">
      <Typography.Title level={4}>Uptime monitor</Typography.Title>
      <Table
        loading={loading}
        columns={[
          {
            title: "Component Name",
            dataIndex: "Component",
          },
          {
            title: "Uptime",
            dataIndex: "Uptime",
          },
          {
            title: "Status",
            dataIndex: "Status",
            render: (link) => {
              return <Avatar src={link} />;
            },
          },
          {
            title: "Mail sent?",
            dataIndex: "MailSent",
          },
          
        ]}
        dataSource={dataSource}
        pagination={{
          pageSize: 5,
        }}
      ></Table>
    </Space>
  );
}
export default Uptime;

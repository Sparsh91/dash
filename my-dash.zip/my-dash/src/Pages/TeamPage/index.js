import React from "react";
import { Table, Typography } from "antd";

const { Title } = Typography;

function TeamPage() {
  // Mock data for team members
  const teamMembers = [
    { key: "1", name: "Alice Johnson", email: "alice.johnson@example.com" },
    { key: "2", name: "Bob Smith", email: "bob.smith@example.com" },
    { key: "3", name: "Carla Gomez", email: "carla.gomez@example.com" },
  ];

  // Mock data for support queries
  const supportQueries = [
    {
      key: "1",
      queryNumber: "SUP-001",
      queryLink: "https://support.example.com/SUP-001",
      confluenceLink: "https://confluence.example.com/SUP-001",
    },
    {
      key: "2",
      queryNumber: "SUP-002",
      queryLink: "https://support.example.com/SUP-002",
      confluenceLink: "https://confluence.example.com/SUP-002",
    },
    {
      key: "3",
      queryNumber: "SUP-003",
      queryLink: "https://support.example.com/SUP-003",
      confluenceLink: "https://confluence.example.com/SUP-003",
    },
  ];

  // Define columns for the team members table
  const teamColumns = [
    {
      title: "Name",
      dataIndex: "name",
      key: "name",
    },
    {
      title: "Email",
      dataIndex: "email",
      key: "email",
    },
  ];

  // Define columns for the support queries table
  const supportColumns = [
    {
      title: "Query Number",
      dataIndex: "queryNumber",
      key: "queryNumber",
    },
    {
      title: "Query Link",
      dataIndex: "queryLink",
      key: "queryLink",
      render: (text) => (
        <a href={text} target="_blank" rel="noopener noreferrer">
          Support Query
        </a>
      ),
    },
    {
      title: "Confluence Link",
      dataIndex: "confluenceLink",
      key: "confluenceLink",
      render: (text) => (
        <a href={text} target="_blank" rel="noopener noreferrer">
          Confluence Page
        </a>
      ),
    },
  ];

  return (
    <div style={{ padding: "20px" }}>
      <Title level={3}>Team Members</Title>
      <Table
        columns={teamColumns}
        dataSource={teamMembers}
        pagination={false}
        style={{ marginBottom: "20px" }}
      />

      <Title level={3}>Active Support Queries</Title>
      <Table
        columns={supportColumns}
        dataSource={supportQueries}
        pagination={false}
      />
    </div>
  );
}

export default TeamPage;

import React, { useState } from "react";
import { Select, Typography, Row, Col, Card } from "antd";
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from "recharts";

const { Title } = Typography;
const { Option } = Select;

// Mock TPS data for different environments
const data = {
  dev: [
    { time: "00:00", component1: 10, component2: 20 },
    { time: "02:00", component1: 15, component2: 25 },
    { time: "04:00", component1: 20, component2: 30 },
    { time: "06:00", component1: 25, component2: 35 },
    { time: "08:00", component1: 30, component2: 40 },
    { time: "10:00", component1: 35, component2: 45 },
    { time: "12:00", component1: 40, component2: 50 },
    { time: "14:00", component1: 45, component2: 55 },
    { time: "16:00", component1: 50, component2: 60 },
    { time: "18:00", component1: 55, component2: 65 },
    { time: "20:00", component1: 60, component2: 70 },
    { time: "22:00", component1: 65, component2: 75 },
  ],
  staging: [
    { time: "00:00", component1: 20, component2: 30 },
    { time: "02:00", component1: 25, component2: 35 },
    { time: "04:00", component1: 30, component2: 40 },
    { time: "06:00", component1: 35, component2: 45 },
    { time: "08:00", component1: 40, component2: 50 },
    { time: "10:00", component1: 45, component2: 55 },
    { time: "12:00", component1: 50, component2: 60 },
    { time: "14:00", component1: 55, component2: 65 },
    { time: "16:00", component1: 60, component2: 70 },
    { time: "18:00", component1: 65, component2: 75 },
    { time: "20:00", component1: 70, component2: 80 },
    { time: "22:00", component1: 75, component2: 85 },
  ],
  prod: [
    { time: "00:00", component1: 30, component2: 40 },
    { time: "02:00", component1: 35, component2: 45 },
    { time: "04:00", component1: 40, component2: 50 },
    { time: "06:00", component1: 45, component2: 55 },
    { time: "08:00", component1: 50, component2: 60 },
    { time: "10:00", component1: 55, component2: 65 },
    { time: "12:00", component1: 60, component2: 70 },
    { time: "14:00", component1: 65, component2: 75 },
    { time: "16:00", component1: 70, component2: 80 },
    { time: "18:00", component1: 75, component2: 85 },
    { time: "20:00", component1: 80, component2: 90 },
    { time: "22:00", component1: 85, component2: 95 },
  ],
};

const TPSDashboard = () => {
  const [environment, setEnvironment] = useState("dev");
  const [tpsData, setTpsData] = useState(data[environment]);

  const handleEnvironmentChange = (value) => {
    setEnvironment(value);
    setTpsData(data[value]);
  };

  return (
    <div style={{ padding: "20px" }}>
      <Title level={3}>TPS Dashboard</Title>
      <Select defaultValue="dev" onChange={handleEnvironmentChange} style={{ width: 200, marginBottom: 20 }}>
        <Option value="dev">DSIT</Option>
        <Option value="staging">Staging</Option>
        <Option value="prod">Production</Option>
      </Select>
      
      <Row gutter={400}>
        <Col span={20}>
          <Card title="Orchestrator TPS" bordered={false}>
            <ResponsiveContainer width="100%" height={300}>
              <LineChart data={tpsData}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="time" />
                <YAxis />
                <Tooltip />
                <Legend />
                <Line type="monotone" dataKey="component1" stroke="#8884d8" activeDot={{ r: 8 }} />
              </LineChart>
            </ResponsiveContainer>
          </Card>
        </Col>
        
        <Col span={30}>
          <Card title="IG TPS" bordered={false}>
            <ResponsiveContainer width="100%" height={300}>
              <LineChart data={tpsData}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="time" />
                <YAxis />
                <Tooltip />
                <Legend />
                <Line type="monotone" dataKey="component2" stroke="#82ca9d" activeDot={{ r: 8 }} />
              </LineChart>
            </ResponsiveContainer>
          </Card>
        </Col>
      </Row>
    </div>
  );
};

export default TPSDashboard;

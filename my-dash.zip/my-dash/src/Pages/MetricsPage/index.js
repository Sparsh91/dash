import React, { useState, useEffect } from "react";
import { Card, Progress, Typography, Space, Select } from "antd";

const { Option } = Select;
const { Title, Text } = Typography;

function MetricsPage() {
  const [selectedOption, setSelectedOption] = useState("option1");
  
  const [metrics, setMetrics] = useState({
    cpuUtilization: 0,
    memoryUtilization: 0,
    heapSize: 0,
  });

  // Mock function to simulate fetching data
  const fetchMetrics = () => {
    setMetrics({
      cpuUtilization: Math.floor(Math.random() * 100), // Simulate CPU usage percentage
      memoryUtilization: Math.floor(Math.random() * 100), // Simulate memory usage percentage
      heapSize: Math.floor(Math.random() * 100), // Simulate heap size percentage
    });
  };

  // Use effect to update metrics every 5 seconds
  useEffect(() => {
    const interval = setInterval(() => {
      fetchMetrics();
    }, 5000); // Update every 5 seconds

    return () => clearInterval(interval); // Cleanup on component unmount
  }, []);

  const handleSelectChange = (value) => {
    setSelectedOption(value);
  };


  return (
    <div style={{ padding: "20px" }}>
      <Title level={2}>System Metrics</Title>
      
      <Title level={3}>Select an Environment</Title>
      <Select
        defaultValue="DSIT"
        style={{ width: 200, marginBottom: "20px" }}
        onChange={handleSelectChange}
      >
        <Option value="DSIT">DSIT</Option>
        <Option value="HQA">HQA</Option>
        <Option value="RQA">RQA</Option>
      </Select>

      <Space direction="horizontal " size="large" style={{ width: "100%" }}>
        {/* CPU Utilization */}
        <Card title="CPU Utilization" bordered={false}>
          <Progress
            type="circle"
            percent={metrics.cpuUtilization}
            strokeColor={metrics.cpuUtilization > 80 ? "red" : "green"}
          />
          <Text style={{ display: "block", marginTop: "10px" }}>
            {metrics.cpuUtilization}% Utilization
          </Text>
        </Card>

        {/* Memory Utilization */}
        <Card title="Memory Utilization" bordered={false}>
          <Progress
            type="circle"
            percent={metrics.memoryUtilization}
            strokeColor={metrics.memoryUtilization > 80 ? "red" : "blue"}
          />
          <Text style={{ display: "block", marginTop: "10px" }}>
            {metrics.memoryUtilization}% Utilization
          </Text>
        </Card>

        {/* Heap Size Status */}
        <Card title="Heap Size" bordered={false}>
          <Progress
            type="circle"
            percent={metrics.heapSize}
            strokeColor={metrics.heapSize > 80 ? "red" : "purple"}
          />
          <Text style={{ display: "block", marginTop: "10px" }}>
            {metrics.heapSize}% of Total Heap Size Used
          </Text>
        </Card>
      </Space>
    </div>
  );
}

export default MetricsPage;
